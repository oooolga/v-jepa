from .tensors import trunc_normal_

__all__ = ['trunc_normal_']